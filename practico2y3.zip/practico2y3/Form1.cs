﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practico2y3
{
    public partial class Frm2 : Form
    {
        public Frm2()
        {
            InitializeComponent();
        }

        private void TDni_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verificamos si la tecla presionada NO es un número y NO es una tecla de control 
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) ){
                // Si es una letra o símbolo, cancelamos el ingreso
                e.Handled = true;
            }
        }

        private void TApellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void TApellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verificamos que solo sean letras, teclas de control o espacios
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) ) {
                e.Handled = true; // Si es un número o símbolo raro, lo cancelamos
            }
        }

        private void TNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verificamos que solo sean letras, teclas de control o espacios
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Si es un número o símbolo raro, lo cancelamos
            }
        }

        private void TGuardar_Click(object sender, EventArgs e)
        {
            // Verificamos si algún campo está vacío 
            if (TDni.Text == "" || TApellido.Text == "" || TNombre.Text == "" || TTelefono.Text == "")
            {
                MessageBox.Show("Debe Completar todos los campos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // 1. Declaramos la variable para capturar la respuesta del MsgBox
                DialogResult ask;

                // 2. Mostramos el mensaje de consulta (con botones Sí/No y el ícono de interrogación
                ask = MessageBox.Show(
                    "Seguro que desea insertar un nuevo Cliente?",
                    "Confirmar Insercion",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button1 // Asegura que el foco esté en "Sí" por defecto
                );

                // 3. Utilizamos la sentencia if para verificar si el usuario hizo clic en "Sí"
                if (ask == DialogResult.Yes)
                {
                    // 4. Modificamos el label superior
                    LModificar.Text = TNombre.Text + " " + TApellido.Text;
                    LModificar.ForeColor = Color.Red;

                    // 5. Mostramos el mensaje de información confirmando la inserción
                    MessageBox.Show(
                        "El Cliente: " + TNombre.Text + " " + TApellido.Text + " se insertó Correctamente",
                        "Guardar",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
            }
        }

        private void TEliminar_Click(object sender, EventArgs e)
        {
            // 1. VALIDACIÓN: Comprobamos que los campos no estén vacíos antes de hacer nada
            if (TDni.Text == "" || TApellido.Text == "" || TNombre.Text == "")
            {
                MessageBox.Show("No hay datos cargados para eliminar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // El 'return' frena el código acá para que no pregunte por borrar a un "fantasma"
            }

            // 2. PREPARACIÓN: Unimos el apellido y el nombre en una sola variable para usarla más fácil
            string nombreCompleto = $"{TApellido.Text} {TNombre.Text}";

            // 3. PREGUNTA: Mostramos el cartel de confirmación 
            // (MessageBoxDefaultButton.Button2 hace que el "No" esté seleccionado por defecto por seguridad)
            DialogResult respuesta = MessageBox.Show(
                $"¿Está a punto de eliminar al cliente: {nombreCompleto}?",
                "Confirmar Eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Exclamation,
                MessageBoxDefaultButton.Button2
            );

            // 4. ACCIÓN: Si el usuario eligió "Sí", confirmamos y limpiamos la pantalla
            if (respuesta == DialogResult.Yes)
            {
                // Mostramos el mensaje de éxito
                MessageBox.Show($"El Cliente: {nombreCompleto} se eliminó correctamente.", "Eliminar", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Vaciamos las cajas de texto
                TDni.Clear();
                TApellido.Clear();
                TNombre.Clear();

                // Borramos también el texto del Label rojo
                LModificar.Text = "";
            }
        }

        private void Frm2_Load(object sender, EventArgs e)
        {
            // Carga la imagen del varón apenas abre el programa
            picture.BackgroundImage = Properties.Resources.negocioH;
        }

        private void LModificar_Click(object sender, EventArgs e)
        {

        }

        private void TSalir_KeyPress(object sender, KeyPressEventArgs e)
        {
            // cerrar formulario
            this.Close();
        }

        private void picture_Click(object sender, EventArgs e)
        {

        }

        private void RBVaron_CheckedChanged(object sender, EventArgs e)
        {
            // Verificamos si la opción seleccionada es la del varón
            if (RBVaron.Checked == true)
            {
                // Usamos BackgroundImage 
                picture.BackgroundImage = Properties.Resources.negocioH;
            }
        }

        private void RBMujer_CheckedChanged(object sender, EventArgs e)
        {
            // Verificamos si la opción seleccionada es la del mujer
            if (RBMujer.Checked == true)
            {
                // Usamos BackgroundImage 
                picture.BackgroundImage = Properties.Resources.negocioM;
            }
        }

        private void TTelefono_TextChanged(object sender, EventArgs e)
        {

        }

        private void TTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Si es un número o símbolo raro, lo cancelamos
            }
        }

        private void TSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
