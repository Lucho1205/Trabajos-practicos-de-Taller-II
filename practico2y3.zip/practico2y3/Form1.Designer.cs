﻿namespace practico2y3
{
    partial class Frm2
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LApellido = new System.Windows.Forms.Label();
            this.LN = new System.Windows.Forms.Label();
            this.LDni = new System.Windows.Forms.Label();
            this.LNombre = new System.Windows.Forms.Label();
            this.LModificar = new System.Windows.Forms.Label();
            this.TDni = new System.Windows.Forms.TextBox();
            this.TApellido = new System.Windows.Forms.TextBox();
            this.TNombre = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkMastercard = new System.Windows.Forms.CheckBox();
            this.chkVisa = new System.Windows.Forms.CheckBox();
            this.chkNaranja = new System.Windows.Forms.CheckBox();
            this.LTarjetas = new System.Windows.Forms.Label();
            this.TTelefono = new System.Windows.Forms.TextBox();
            this.LTelefono = new System.Windows.Forms.Label();
            this.RBVaron = new System.Windows.Forms.RadioButton();
            this.RBMujer = new System.Windows.Forms.RadioButton();
            this.LNuevoCliente = new System.Windows.Forms.Label();
            this.TSalir = new System.Windows.Forms.Button();
            this.picture = new System.Windows.Forms.PictureBox();
            this.TEliminar = new System.Windows.Forms.Button();
            this.TGuardar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).BeginInit();
            this.SuspendLayout();
            // 
            // LApellido
            // 
            this.LApellido.AutoSize = true;
            this.LApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LApellido.Location = new System.Drawing.Point(20, 117);
            this.LApellido.Name = "LApellido";
            this.LApellido.Size = new System.Drawing.Size(82, 25);
            this.LApellido.TabIndex = 0;
            this.LApellido.Text = "Apellido";
            // 
            // LN
            // 
            this.LN.AutoSize = true;
            this.LN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LN.Location = new System.Drawing.Point(21, 21);
            this.LN.Name = "LN";
            this.LN.Size = new System.Drawing.Size(177, 25);
            this.LN.TabIndex = 1;
            this.LN.Text = "Nombre y Apellido:";
            // 
            // LDni
            // 
            this.LDni.AutoSize = true;
            this.LDni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDni.Location = new System.Drawing.Point(21, 70);
            this.LDni.Name = "LDni";
            this.LDni.Size = new System.Drawing.Size(45, 25);
            this.LDni.TabIndex = 2;
            this.LDni.Text = "DNI";
            // 
            // LNombre
            // 
            this.LNombre.AutoSize = true;
            this.LNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNombre.Location = new System.Drawing.Point(22, 173);
            this.LNombre.Name = "LNombre";
            this.LNombre.Size = new System.Drawing.Size(81, 25);
            this.LNombre.TabIndex = 3;
            this.LNombre.Text = "Nombre";
            // 
            // LModificar
            // 
            this.LModificar.AutoSize = true;
            this.LModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LModificar.ForeColor = System.Drawing.Color.Red;
            this.LModificar.Location = new System.Drawing.Point(241, 21);
            this.LModificar.Name = "LModificar";
            this.LModificar.Size = new System.Drawing.Size(90, 25);
            this.LModificar.TabIndex = 4;
            this.LModificar.Text = "modificar";
            this.LModificar.Click += new System.EventHandler(this.LModificar_Click);
            // 
            // TDni
            // 
            this.TDni.Location = new System.Drawing.Point(135, 74);
            this.TDni.Name = "TDni";
            this.TDni.Size = new System.Drawing.Size(135, 22);
            this.TDni.TabIndex = 5;
            this.TDni.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TDni_KeyPress);
            // 
            // TApellido
            // 
            this.TApellido.Location = new System.Drawing.Point(135, 121);
            this.TApellido.Name = "TApellido";
            this.TApellido.Size = new System.Drawing.Size(135, 22);
            this.TApellido.TabIndex = 6;
            this.TApellido.TextChanged += new System.EventHandler(this.TApellido_TextChanged);
            this.TApellido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TApellido_KeyPress);
            // 
            // TNombre
            // 
            this.TNombre.Location = new System.Drawing.Point(135, 177);
            this.TNombre.Name = "TNombre";
            this.TNombre.Size = new System.Drawing.Size(135, 22);
            this.TNombre.TabIndex = 7;
            this.TNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TNombre_KeyPress);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.chkMastercard);
            this.panel1.Controls.Add(this.chkVisa);
            this.panel1.Controls.Add(this.chkNaranja);
            this.panel1.Controls.Add(this.LTarjetas);
            this.panel1.Controls.Add(this.TTelefono);
            this.panel1.Controls.Add(this.LTelefono);
            this.panel1.Controls.Add(this.LModificar);
            this.panel1.Controls.Add(this.LN);
            this.panel1.Controls.Add(this.LNombre);
            this.panel1.Controls.Add(this.TNombre);
            this.panel1.Controls.Add(this.LApellido);
            this.panel1.Controls.Add(this.TApellido);
            this.panel1.Controls.Add(this.LDni);
            this.panel1.Controls.Add(this.TDni);
            this.panel1.Location = new System.Drawing.Point(23, 83);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(412, 385);
            this.panel1.TabIndex = 10;
            // 
            // chkMastercard
            // 
            this.chkMastercard.AutoSize = true;
            this.chkMastercard.Location = new System.Drawing.Point(226, 360);
            this.chkMastercard.Name = "chkMastercard";
            this.chkMastercard.Size = new System.Drawing.Size(97, 20);
            this.chkMastercard.TabIndex = 13;
            this.chkMastercard.Text = "Mastercard";
            this.chkMastercard.UseVisualStyleBackColor = true;
            // 
            // chkVisa
            // 
            this.chkVisa.AutoSize = true;
            this.chkVisa.Location = new System.Drawing.Point(226, 334);
            this.chkVisa.Name = "chkVisa";
            this.chkVisa.Size = new System.Drawing.Size(56, 20);
            this.chkVisa.TabIndex = 12;
            this.chkVisa.Text = "Visa";
            this.chkVisa.UseVisualStyleBackColor = true;
            // 
            // chkNaranja
            // 
            this.chkNaranja.AutoSize = true;
            this.chkNaranja.Location = new System.Drawing.Point(226, 308);
            this.chkNaranja.Name = "chkNaranja";
            this.chkNaranja.Size = new System.Drawing.Size(77, 20);
            this.chkNaranja.TabIndex = 11;
            this.chkNaranja.Text = "Naranja";
            this.chkNaranja.UseVisualStyleBackColor = true;
            // 
            // LTarjetas
            // 
            this.LTarjetas.AutoSize = true;
            this.LTarjetas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTarjetas.Location = new System.Drawing.Point(20, 292);
            this.LTarjetas.Name = "LTarjetas";
            this.LTarjetas.Size = new System.Drawing.Size(189, 25);
            this.LTarjetas.TabIndex = 10;
            this.LTarjetas.Text = "Tarjetas de créditos:";
            // 
            // TTelefono
            // 
            this.TTelefono.Location = new System.Drawing.Point(135, 240);
            this.TTelefono.Name = "TTelefono";
            this.TTelefono.Size = new System.Drawing.Size(135, 22);
            this.TTelefono.TabIndex = 9;
            this.TTelefono.TextChanged += new System.EventHandler(this.TTelefono_TextChanged);
            this.TTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TTelefono_KeyPress);
            // 
            // LTelefono
            // 
            this.LTelefono.AutoSize = true;
            this.LTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTelefono.Location = new System.Drawing.Point(22, 236);
            this.LTelefono.Name = "LTelefono";
            this.LTelefono.Size = new System.Drawing.Size(89, 25);
            this.LTelefono.TabIndex = 8;
            this.LTelefono.Text = "Teléfono";
            // 
            // RBVaron
            // 
            this.RBVaron.AutoSize = true;
            this.RBVaron.Checked = true;
            this.RBVaron.Location = new System.Drawing.Point(558, 226);
            this.RBVaron.Name = "RBVaron";
            this.RBVaron.Size = new System.Drawing.Size(64, 20);
            this.RBVaron.TabIndex = 12;
            this.RBVaron.TabStop = true;
            this.RBVaron.Text = "Varón";
            this.RBVaron.UseVisualStyleBackColor = true;
            this.RBVaron.CheckedChanged += new System.EventHandler(this.RBVaron_CheckedChanged);
            // 
            // RBMujer
            // 
            this.RBMujer.AutoSize = true;
            this.RBMujer.Location = new System.Drawing.Point(670, 226);
            this.RBMujer.Name = "RBMujer";
            this.RBMujer.Size = new System.Drawing.Size(61, 20);
            this.RBMujer.TabIndex = 13;
            this.RBMujer.Text = "Mujer";
            this.RBMujer.UseVisualStyleBackColor = true;
            this.RBMujer.CheckedChanged += new System.EventHandler(this.RBMujer_CheckedChanged);
            // 
            // LNuevoCliente
            // 
            this.LNuevoCliente.AutoSize = true;
            this.LNuevoCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNuevoCliente.ForeColor = System.Drawing.Color.RoyalBlue;
            this.LNuevoCliente.Location = new System.Drawing.Point(262, 9);
            this.LNuevoCliente.Name = "LNuevoCliente";
            this.LNuevoCliente.Size = new System.Drawing.Size(266, 42);
            this.LNuevoCliente.TabIndex = 15;
            this.LNuevoCliente.Text = "Nuevo Cliente";
            // 
            // TSalir
            // 
            this.TSalir.Image = global::practico2y3.Properties.Resources.tSalir;
            this.TSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TSalir.Location = new System.Drawing.Point(575, 501);
            this.TSalir.Name = "TSalir";
            this.TSalir.Size = new System.Drawing.Size(156, 74);
            this.TSalir.TabIndex = 14;
            this.TSalir.Text = "Salir";
            this.TSalir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.TSalir.UseVisualStyleBackColor = true;
            this.TSalir.Click += new System.EventHandler(this.TSalir_Click);
            this.TSalir.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TSalir_KeyPress);
            // 
            // picture
            // 
            this.picture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picture.Location = new System.Drawing.Point(558, 40);
            this.picture.Name = "picture";
            this.picture.Size = new System.Drawing.Size(173, 162);
            this.picture.TabIndex = 11;
            this.picture.TabStop = false;
            this.picture.Click += new System.EventHandler(this.picture_Click);
            // 
            // TEliminar
            // 
            this.TEliminar.Image = global::practico2y3.Properties.Resources.Iconos_gratuitos_de_Eliminar_Carpeta_diseñados_por_Andrean_Prabowo;
            this.TEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TEliminar.Location = new System.Drawing.Point(269, 501);
            this.TEliminar.Name = "TEliminar";
            this.TEliminar.Size = new System.Drawing.Size(166, 74);
            this.TEliminar.TabIndex = 9;
            this.TEliminar.Text = "Eliminar";
            this.TEliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.TEliminar.UseVisualStyleBackColor = true;
            this.TEliminar.Click += new System.EventHandler(this.TEliminar_Click);
            // 
            // TGuardar
            // 
            this.TGuardar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TGuardar.Image = global::practico2y3.Properties.Resources.guardar1;
            this.TGuardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TGuardar.Location = new System.Drawing.Point(23, 501);
            this.TGuardar.Name = "TGuardar";
            this.TGuardar.Size = new System.Drawing.Size(166, 74);
            this.TGuardar.TabIndex = 8;
            this.TGuardar.Text = "Guardar";
            this.TGuardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.TGuardar.UseVisualStyleBackColor = true;
            this.TGuardar.Click += new System.EventHandler(this.TGuardar_Click);
            // 
            // Frm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 586);
            this.Controls.Add(this.LNuevoCliente);
            this.Controls.Add(this.TSalir);
            this.Controls.Add(this.RBMujer);
            this.Controls.Add(this.RBVaron);
            this.Controls.Add(this.picture);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TEliminar);
            this.Controls.Add(this.TGuardar);
            this.Name = "Frm2";
            this.Text = "Pequeño Formulario";
            this.Load += new System.EventHandler(this.Frm2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LApellido;
        private System.Windows.Forms.Label LN;
        private System.Windows.Forms.Label LDni;
        private System.Windows.Forms.Label LNombre;
        private System.Windows.Forms.Label LModificar;
        private System.Windows.Forms.TextBox TDni;
        private System.Windows.Forms.TextBox TApellido;
        private System.Windows.Forms.TextBox TNombre;
        private System.Windows.Forms.Button TGuardar;
        private System.Windows.Forms.Button TEliminar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox TTelefono;
        private System.Windows.Forms.Label LTelefono;
        private System.Windows.Forms.Label LTarjetas;
        private System.Windows.Forms.CheckBox chkMastercard;
        private System.Windows.Forms.CheckBox chkVisa;
        private System.Windows.Forms.CheckBox chkNaranja;
        private System.Windows.Forms.PictureBox picture;
        private System.Windows.Forms.RadioButton RBVaron;
        private System.Windows.Forms.RadioButton RBMujer;
        private System.Windows.Forms.Button TSalir;
        private System.Windows.Forms.Label LNuevoCliente;
    }
}

