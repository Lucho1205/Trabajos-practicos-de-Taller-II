﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tp4
{
    public partial class Form1 : Form
    {
        // Variables a nivel de clase
        string Source;
        string archivo;
        string Destination;

        // Saldo por debajo del cual la fila se pinta de rojo (punto 8)
        private const decimal SALDO_MINIMO = 50;

        public Form1()
        {
            InitializeComponent();

            // Filtro para que el diálogo solo deje elegir imágenes
            openFileDialog1.Filter = "Archivos Imagenes|*.jpg|Archivos Imagenes|*.bmp|Archivos Imagenes|*.png";

            // Enlace de eventos
            this.Load += Form1_Load;
            btnAgregar.Click += btnAgregar_Click;
            DDatos.CellContentClick += DDatos_CellContentClick;
            DDatos.CellClick += DDatos_CellClick;
            txtNombre.TextChanged += Formatear_TextChanged;
            txtApellido.TextChanged += Formatear_TextChanged;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pbFoto.SizeMode = PictureBoxSizeMode.Zoom;
            pbFoto.BackgroundImageLayout = ImageLayout.Zoom;
            txtFoto.ReadOnly = true;

            // Ajusta el ícono del disquete a un tamaño chico
            btnAgregar.Image = new Bitmap(Properties.Resources.guardarYa, new Size(32, 32));

            ConfigurarGrid();
        }

        // ---------- Puntos 3 y 4: botón Foto ----------
        private void btnFoto_Click(object sender, EventArgs e)
        {
            // Solo abre el diálogo. Todo lo demás lo maneja openFileDialog1_FileOk.
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                // Carpeta Fotos junto al .exe (bin\Debug\Fotos)
                string carpetaFotos = Path.Combine(Application.StartupPath, "Fotos");

                if (!Directory.Exists(carpetaFotos))
                {
                    Directory.CreateDirectory(carpetaFotos);
                }

                Source = openFileDialog1.FileName;                  // Ruta completa del archivo elegido
                archivo = StrSacaValoresString(Source);              // Solo el nombre del archivo
                Destination = Path.Combine(carpetaFotos, archivo);   // Ruta destino dentro del proyecto

                // Solo copia si origen y destino no son el mismo archivo
                if (!string.Equals(Source, Destination, StringComparison.OrdinalIgnoreCase))
                {
                    File.Copy(Source, Destination, true);
                }

                // Carga una copia en memoria para no bloquear el archivo
                using (Image original = Image.FromFile(Destination))
                {
                    pbFoto.Image = new Bitmap(original);
                }

                // Solo se escribe la ruta si la imagen se cargó bien
                txtFoto.Text = Destination;
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo cargar la imagen: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }

        // Función auxiliar de la cátedra: devuelve solo el nombre del archivo
        // (lo que está después de la última "\").
        string StrSacaValoresString(string RutaPathFichero)
        {
            string ChrsIn, ChrsOut = "";

            if (RutaPathFichero == "")
                MessageBox.Show("Debe seleccionar un archivo");

            ChrsIn = RutaPathFichero;

            if (ChrsIn.Contains("\\"))
            {
                for (int IdX = ChrsIn.Length; IdX >= 1; IdX--)
                {
                    if (ChrsIn.Substring(IdX - 1, 1) == "\\")
                    {
                        ChrsOut = ChrsIn.Substring(IdX);
                        break;
                    }
                }
            }
            else if (ChrsIn.IndexOf(":") == 1)
            {
                ChrsOut = ChrsIn.Substring(2);
            }
            else
            {
                ChrsOut = ChrsIn;
            }

            return ChrsOut;
        }

        // ---------- Puntos 6 y 7: columnas del grid ----------
        private void ConfigurarGrid()
        {
            DDatos.AllowUserToAddRows = false;
            DDatos.ReadOnly = true;
            DDatos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DDatos.RowTemplate.Height = 80;   // antes de agregar filas

            var colApellido = new DataGridViewTextBoxColumn();
            colApellido.Name = "Apellido";
            colApellido.HeaderText = "Apellido";
            colApellido.DefaultCellStyle.Font = new Font("Monotype Corsiva", 15, FontStyle.Italic);

            var colNombre = new DataGridViewTextBoxColumn();
            colNombre.Name = "Nombre";
            colNombre.HeaderText = "Nombre";
            colNombre.DefaultCellStyle.Font = new Font("Times New Roman", 14, FontStyle.Bold); // distinta a Apellido

            var colFecha = new DataGridViewTextBoxColumn();
            colFecha.Name = "Fecha";
            colFecha.HeaderText = "Fecha Nacimiento";

            var colSexo = new DataGridViewTextBoxColumn();
            colSexo.Name = "Sexo";
            colSexo.HeaderText = "Sexo";

            var colEliminar = new DataGridViewButtonColumn();
            colEliminar.Name = "Eliminar";
            colEliminar.HeaderText = "Eliminar";
            colEliminar.Text = "Eliminar";
            colEliminar.UseColumnTextForButtonValue = true;

            var colSaldo = new DataGridViewTextBoxColumn();
            colSaldo.Name = "Saldo";
            colSaldo.HeaderText = "Saldo";

            var colFoto = new DataGridViewImageColumn();
            colFoto.Name = "Foto";
            colFoto.HeaderText = "Foto";
            colFoto.ImageLayout = DataGridViewImageCellLayout.Stretch;

            var colRuta = new DataGridViewTextBoxColumn();
            colRuta.Name = "Ruta";
            colRuta.HeaderText = "Ruta";

            DDatos.Columns.AddRange(colApellido, colNombre, colFecha, colSexo,
                                    colEliminar, colSaldo, colFoto, colRuta);

            // Estas van DESPUÉS de agregar las columnas
            DDatos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            colRuta.FillWeight = 60;
        }

        // ---------- Punto 5: primera mayúscula, resto minúscula ----------
        private string Capitalizar(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            CultureInfo cultura = CultureInfo.CurrentCulture;
            return char.ToUpper(s[0], cultura) + s.Substring(1).ToLower(cultura);
        }

        private void Formatear_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            string formateado = Capitalizar(t.Text);
            if (t.Text != formateado)
            {
                int pos = t.SelectionStart;   // para que el cursor no salte al principio
                t.Text = formateado;
                t.SelectionStart = pos;
            }
        }

        // ---------- Puntos 7, 8, 10 y 11: botón Agregar ----------
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text.Trim() == "" || txtApellido.Text.Trim() == "")
            {
                MessageBox.Show("Complete nombre y apellido");
                return;
            }
            if (!rbHombre.Checked && !rbMujer.Checked)
            {
                MessageBox.Show("Seleccione el sexo");
                return;
            }
            decimal saldo;
            if (!decimal.TryParse(txtSaldo.Text, out saldo) || saldo < 0)
            {
                MessageBox.Show("El saldo debe ser un número mayor o igual a 0");
                return;
            }

            // Punto 10: guarda la leyenda del RadioButton
            string sexo = rbHombre.Checked ? "Hombre" : "Mujer";

            // Punto 11: si no eligió foto, se usa la imagen por defecto (avatar).
            // Se clona para que la celda no dependa del PictureBox.
            Image origen = pbFoto.Image ?? pbFoto.BackgroundImage;
            Image img = origen != null ? new Bitmap(origen) : null;

            int fila = DDatos.Rows.Add(
                txtApellido.Text.Trim(),
                txtNombre.Text.Trim(),
                dtpFecha.Value.ToShortDateString(),
                sexo,
                "Eliminar",
                saldo,
                img,
                txtFoto.Text);

            // Punto 8: saldo menor a 50 => fila roja (también al seleccionarla)
            if (saldo < SALDO_MINIMO)
            {
                DDatos.Rows[fila].DefaultCellStyle.BackColor = Color.Red;
                DDatos.Rows[fila].DefaultCellStyle.SelectionBackColor = Color.DarkRed;
            }

            LimpiarCampos();
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtSaldo.Clear();
            txtFoto.Clear();

            // Libera la foto anterior; vuelve a verse el avatar de fondo
            if (pbFoto.Image != null)
            {
                pbFoto.Image.Dispose();
                pbFoto.Image = null;
            }

            rbHombre.Checked = false;
            rbMujer.Checked = false;
            txtNombre.Focus();
        }

        // ---------- Puntos 7 y 9: botón Eliminar dentro del grid ----------
        private void DDatos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;   // click en el encabezado

            if (DDatos.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                DialogResult respuesta = MessageBox.Show(
                    "¿Desea eliminar el registro?", "Confirmar",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (respuesta == DialogResult.Yes)
                {
                    DDatos.Rows.RemoveAt(e.RowIndex);
                    rbHombre.Checked = false;
                    rbMujer.Checked = false;
                }
            }
        }

        // ---------- Punto 10: al seleccionar una fila, marca el RadioButton ----------
        private void DDatos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            string sexo = DDatos.Rows[e.RowIndex].Cells["Sexo"].Value?.ToString();
            rbHombre.Checked = (sexo == "Hombre");
            rbMujer.Checked = (sexo == "Mujer");
        }

        // Enlazado desde el Designer; no hace nada
        private void pbFoto_Click(object sender, EventArgs e)
        {
        }
    }
}