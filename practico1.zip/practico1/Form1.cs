﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practico1
{
    public partial class Formulario1 : Form
    {
        public Formulario1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BEliminar_Click(object sender, EventArgs e)
        {
            txtSalida.Clear();
        }

        private void LApellido_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BGuardar_Click(object sender, EventArgs e)
        {
            // Al Botón guardar darle un evento que al hacer click concatene el Apellido y el Nombre y lo muestre en la salida.
            txtSalida.Text = txtApellido.Text + " " + txtNombre.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void BSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Formulario1_KeyDown(object sender, KeyEventArgs e)
        {
            // Verificamos si se presionó la tecla Control y la tecla S al mismo tiempo
            if ( e.Control  && e.KeyCode == Keys.S ) { 
                Application.Exit();
            }
        }
    }
}
